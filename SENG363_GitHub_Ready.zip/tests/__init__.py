"""Unit tests for the demo application."""
